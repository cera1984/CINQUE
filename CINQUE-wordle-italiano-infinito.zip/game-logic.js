/* Motore indipendente dalla UI: lettere ripetute e modalità difficile. */
(function (root) {
  'use strict';
  function scoreGuess(guess, answer) {
    const result = Array(5).fill('absent');
    const counts = Object.create(null);
    for (let i = 0; i < 5; i++) counts[answer[i]] = (counts[answer[i]] || 0) + 1;
    for (let i = 0; i < 5; i++) {
      if (guess[i] === answer[i]) {
        result[i] = 'correct';
        counts[guess[i]]--;
      }
    }
    for (let i = 0; i < 5; i++) {
      if (result[i] === 'correct') continue;
      if (counts[guess[i]] > 0) {
        result[i] = 'present';
        counts[guess[i]]--;
      }
    }
    return result;
  }
  function checkHardMode(guess, previous) {
    const required = Object.create(null);
    const green = Array(5).fill(null);
    const yellowPositions = Array.from({length:5},()=>new Set());
    for (const row of previous) {
      const inRow = Object.create(null);
      for (let i = 0; i < 5; i++) {
        const letter = row.word[i];
        if (row.marks[i] === 'correct') green[i] = letter;
        if (row.marks[i] === 'present') yellowPositions[i].add(letter);
        if (row.marks[i] === 'correct' || row.marks[i] === 'present') {
          inRow[letter] = (inRow[letter] || 0) + 1;
        }
      }
      for (const letter of Object.keys(inRow)) required[letter] = Math.max(required[letter] || 0, inRow[letter]);
    }
    for (let i = 0; i < 5; i++) {
      if (green[i] && guess[i] !== green[i]) return `La ${i + 1}ª lettera deve essere ${green[i]}.`;
      if (yellowPositions[i].has(guess[i])) return `La lettera ${guess[i]} non può stare nella posizione ${i + 1}.`;
    }
    for (const [letter, min] of Object.entries(required)) {
      const count = [...guess].filter(char => char === letter).length;
      if (count < min) return min === 1 ? `Devi usare la lettera ${letter}.` : `Devi usare almeno ${min} lettere ${letter}.`;
    }
    return null;
  }
  const api = Object.freeze({ scoreGuess, checkHardMode });
  root.CinqueEngine = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
