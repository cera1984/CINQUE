# CINQUE. — Wordle italiano senza limiti

Un gioco web originale, ispirato alle regole di Wordle e al progetto italiano **Par🇮🇹le**. Grafica e implementazione scritte da zero. Nessuna dipendenza, account, API o server da gestire.

## Funzioni

- Parole italiane di **5 lettere**: 818 soluzioni selezionate, 1.195 parole ammesse come tentativi (versione 1).
- **Partite senza limite giornaliero**: il mazzo evita ripetizioni prima di esaurirsi; poi viene rimescolato.
- 6 tentativi, colori corretti anche quando una lettera è ripetuta.
- Modalità difficile: posizione delle lettere verdi obbligatoria, lettere verdi e gialle da riutilizzare.
- Tema chiaro/scuro e opzione di **nuova partita automatica dopo 15 s** oppure pulsante «NUOVA» / «Gioca ancora».
- Statistiche, serie, grafico tentativi, progresso della partita e impostazioni conservati in `localStorage`.
- Condivisione dei quadratini colorati; accessibilità da tastiera, animazioni ridotte se richieste dal dispositivo.
- PWA: installabile sulla schermata Home, offline dopo il primo caricamento (se pubblicata in HTTPS).

## Pubblicazione gratuita su GitHub Pages

1. Apri [github.com](https://github.com/) ed entra nel tuo account.
2. Crea un nuovo repository pubblico, per esempio `cinque`.
3. **Carica i file e le cartelle contenuti in questo pacchetto nella radice del repository**: `index.html` deve stare nella radice, non dentro un'ulteriore cartella `parola-infinita`.
4. Premi **Commit changes**.
5. Apri **Settings → Pages → Build and deployment**, seleziona **Deploy from a branch**. Scegli `main` e cartella `/(root)`, quindi **Save**.
6. Dopo la pubblicazione, il gioco apparirà su `https://TUO-USERNAME.github.io/cinque/`. Il nome dipende da username e repository scelti.

> Questo pacchetto non pubblica automaticamente un sito e non crea da solo un URL pubblico: occorre caricarlo sull'hosting scelto.

## Installazione su iPhone

1. Apri **l'indirizzo pubblico** in **Safari** (non in un browser incorporato in un'app).
2. Premi **Condividi** → **Aggiungi alla schermata Home**.
3. Conferma il nome «CINQUE.», poi premi **Aggiungi**.
4. Apri l'icona dalla schermata Home. Dopo il primo caricamento con rete, il gioco funziona anche offline.

## Prova in locale

Da un computer con Python, esegui nella cartella principale:

```bash
python3 -m http.server 8000
```

Quindi apri <http://localhost:8000>. Per le PWA serve HTTPS, oppure localhost per i test. Aprire `index.html` direttamente da disco permette normalmente di giocare, ma non attiva il service worker.

## Personalizzazione

- Colori, griglia e impaginazione: `styles.css`.
- Interazione, salvataggi, modal e impostazioni: `app.js`.
- Calcolo colori e validazione difficile: `game-logic.js`.
- Dizionari locali: `data/words.js`. Le liste sorgente editabili sono `data/soluzioni.txt` e `data/aggiunte.txt`. Dopo una modifica, puoi rigenerare `words.js` con `python3 make_dictionary.py`.
- Per modifiche pubblicate, cambia la versione `CACHE` in `sw.js` (per es. da `v1` a `v2`) così la PWA scaricherà i nuovi file.

## Privacy e comportamento

I dati restano **solo nel browser** (localStorage) e non sono sincronizzati tra dispositivi. Cancellare i dati del sito cancella le statistiche. Saltare una partita già iniziata conta come sconfitta; cambiare parola prima del primo tentativo non penalizza. Le 818 soluzioni si ripetono dopo l'esaurimento dell'insieme, in ordine rimescolato: le partite, non il numero di parole distinte, sono illimitate. Alcune parole italiane valide ma non incluse nell'elenco dei tentativi potrebbero essere rifiutate; il dizionario è espandibile.

## Crediti

- Regole ispirate al gioco Wordle; riferimento italiano originale: [Par🇮🇹le](https://pietroppeter.github.io/wordle-it/) di Pietro Peterlongo. Nessun codice originale importato.
- Le liste italiane sono una selezione locale manuale. Per estenderle, una fonte aperta è [napolux/paroleitaliane](https://github.com/napolux/paroleitaliane) (licenza MIT, verificare la provenienza delle singole fonti prima di redistribuire).
