(() => {
  'use strict';
  const WORDS = window.CINQUE_WORDS;
  const ENGINE = window.CinqueEngine;
  if (!WORDS || !ENGINE) {
    document.getElementById('messageText').textContent = 'Impossibile caricare il dizionario. Ricarica la pagina.';
    return;
  }
  const answers = [...new Set(WORDS.answers.map(s => s.toUpperCase()))];
  const allowed = new Set([...WORDS.allowed, ...WORDS.answers].map(s => s.toUpperCase()));
  const storageKey = 'cinque-infinite-v1';
  const $ = id => document.getElementById(id);
  const isReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const rows = ['QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNM'];
  const BACKSPACE = '<svg aria-hidden="true" viewBox="0 0 24 24"><path d="m9 5-7 7 7 7h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H9Z"/><path d="m12 9 6 6m0-6-6 6"/></svg>';
  const blankStats = () => ({ games:0, wins:0, streak:0, best:0, distribution:[0,0,0,0,0,0] });
  const blankSettings = () => ({ theme:'dark', hard:false, auto:true });
  const freshState = () => ({ version:1, settings:blankSettings(), stats:blankStats(), number:0, remaining:[], game:null });
  const defer = (fn, ms) => window.setTimeout(fn, ms);
  let state = restore();
  let revealing = false;
  let autoInterval = null;
  let autoRemaining = 0;
  let toastTimeout = null;
  let modalType = '';
  let lastFocused = null;
  let dialogCancel = null;

  function restore() {
    let loaded;
    try { loaded = JSON.parse(localStorage.getItem(storageKey) || 'null'); } catch (_) { /* private mode */ }
    const base = freshState();
    if (!loaded || loaded.version !== 1 || !loaded.stats || !loaded.settings) return base;
    const s = loaded.stats;
    base.stats = {
      games: positiveInt(s.games), wins: positiveInt(s.wins), streak: positiveInt(s.streak),
      best: positiveInt(s.best), distribution: Array.from({length:6}, (_,i) => positiveInt(s.distribution?.[i]))
    };
    if (base.stats.wins > base.stats.games) base.stats.wins = base.stats.games;
    base.settings = {
      theme: loaded.settings.theme === 'light' ? 'light' : 'dark',
      hard: Boolean(loaded.settings.hard), auto: loaded.settings.auto !== false
    };
    base.number = positiveInt(loaded.number);
    base.remaining = Array.isArray(loaded.remaining)
      ? loaded.remaining.filter(i => Number.isInteger(i) && i >= 0 && i < answers.length)
      : [];
    const g = loaded.game;
    if (g && answers.includes(g.answer) && Array.isArray(g.guesses) && g.guesses.length <= 6) {
      const guesses = g.guesses.filter(x => typeof x?.word === 'string' && /^[A-Z]{5}$/.test(x.word)).map(x => ({word:x.word, marks:ENGINE.scoreGuess(x.word, g.answer)}));
      const win = guesses.some(x => x.word === g.answer);
      base.game = {
        answer:g.answer, guesses, current: /^[A-Z]{0,5}$/.test(g.current) ? g.current : '',
        status: ['won','lost'].includes(g.status) ? g.status : (win ? 'won' : guesses.length === 6 ? 'lost' : 'playing'),
        hard: typeof g.hard === 'boolean' ? g.hard : base.settings.hard
      };
      if (base.game.status !== 'playing') base.game.current = '';
    }
    return base;
  }
  function positiveInt(n) { return Number.isSafeInteger(n) && n > 0 ? n : 0; }
  function save() { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch (_) { /* limited storage */ } }
  function pickAnswer() {
    if (!state.remaining.length) {
      state.remaining = Array.from({ length:answers.length }, (_, i) => i);
      for (let i = state.remaining.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [state.remaining[i], state.remaining[j]] = [state.remaining[j], state.remaining[i]];
      }
      if (state.game?.answer && state.remaining.length > 1) {
        const last = state.remaining.length - 1;
        if (answers[state.remaining[last]] === state.game.answer) [state.remaining[last], state.remaining[0]] = [state.remaining[0], state.remaining[last]];
      }
    }
    return answers[state.remaining.pop()];
  }
  function beginNewRound() {
    stopAuto();
    closeModal();
    revealing = false;
    state.number++;
    state.game = {answer:pickAnswer(), guesses:[], current:'', status:'playing', hard:state.settings.hard};
    save();
    render();
    $('subtitle').textContent = 'Trova la parola nascosta';
    $('statusText').textContent = state.settings.hard ? 'MODALITÀ DIFFICILE' : 'PRONTO A GIOCARE';
  }
  function completeRound(win) {
    const g = state.game;
    if (g.status !== 'playing') return;
    g.status = win ? 'won' : 'lost';
    g.current = '';
    const st = state.stats;
    st.games++;
    if (win) {
      st.wins++;
      st.streak++;
      st.best = Math.max(st.best, st.streak);
      st.distribution[g.guesses.length - 1]++;
    } else st.streak = 0;
    save();
    renderStats();
  }
  function abandonRound() {
    completeRound(false);
    beginNewRound();
    toast('Partita saltata: conta come sconfitta.');
  }
  function confirmNewRound() {
    if (revealing) return;
    const g = state.game;
    if (g.status !== 'playing' || g.guesses.length === 0) return beginNewRound();
    openModal('confirm', 'Salti questa partita?', 'PARTITA IN CORSO', `
      <p>Hai già usato <strong>${g.guesses.length} tentativ${g.guesses.length === 1 ? 'o' : 'i'}</strong>. Se cambi parola ora, la partita viene contata come <strong>sconfitta</strong> e la serie di vittorie si interrompe.</p>
      <div class="modal-actions"><button class="modal-action secondary" id="cancelSkip">Continua</button><button class="modal-action" id="acceptSkip">Salta partita</button></div>
    `);
    $('cancelSkip').addEventListener('click', closeModal);
    $('acceptSkip').addEventListener('click', abandonRound);
  }
  function render() {
    document.body.dataset.theme = state.settings.theme;
    document.querySelector('meta[name="theme-color"]').setAttribute('content', state.settings.theme === 'dark' ? '#10101b' : '#f6f5fa');
    $('roundNumber').textContent = '#' + String(state.number).padStart(3, '0');
    renderStats();
    renderBoard();
    renderKeyboard();
    const g = state.game;
    $('messageText').textContent = g.status === 'won' ? 'Parola indovinata. Ottimo lavoro!' : g.status === 'lost' ? `La parola era ${g.answer}` : `${Math.max(0,6 - g.guesses.length)} tentativi rimasti`;
    $('statusText').textContent = g.status === 'playing' ? (g.hard ? 'MODALITÀ DIFFICILE' : 'PRONTO A GIOCARE') : g.status === 'won' ? 'PARTITA VINTA' : 'PARTITA TERMINATA';
    $('subtitle').textContent = g.status === 'playing' ? 'Trova la parola nascosta' : g.status === 'won' ? 'Hai trovato la parola!' : 'Riprova con una nuova parola';
    $('newGameBtn').setAttribute('aria-label', g.status === 'playing' ? 'Salta e inizia una nuova partita' : 'Inizia una nuova partita');
  }
  function renderStats() {
    $('sideGames').textContent = String(state.stats.games).padStart(2,'0');
    $('sideWins').textContent = String(state.stats.wins).padStart(2,'0');
    $('sideStreak').textContent = String(state.stats.streak).padStart(2,'0');
  }
  function renderBoard() {
    const g = state.game;
    $('board').innerHTML = Array.from({length:6}, (_,r) => {
      const submitted = g.guesses[r];
      const letters = submitted ? submitted.word : r === g.guesses.length && g.status === 'playing' ? g.current : '';
      const cells = Array.from({length:5}, (_,c) => {
        const value = letters[c] || '';
        const classes = ['tile'];
        if (value) classes.push('filled');
        if (submitted) classes.push(submitted.marks[c]);
        else if (r === g.guesses.length && g.status === 'playing' && c === g.current.length) classes.push('active');
        return `<span class="${classes.join(' ')}" aria-label="${value || 'vuoto'}${submitted ? ', ' + submitted.marks[c] : ''}">${value}</span>`;
      }).join('');
      return `<div class="board-row" aria-label="Tentativo ${r + 1}">${cells}</div>`;
    }).join('');
  }
  function renderKeyboard() {
    const priority = { absent:1, present:2, correct:3 };
    const seen = Object.create(null);
    for (const guess of state.game.guesses) for (let i = 0; i < 5; i++) {
      const l = guess.word[i], mark = guess.marks[i];
      if ((priority[mark] || 0) > (priority[seen[l]] || 0)) seen[l] = mark;
    }
    $('keyboard').innerHTML = rows.map((row, i) => {
      let keys = [...row];
      if (i === 2) keys = ['ENTER', ...keys, 'BACK'];
      return `<div class="keyboard-row">${keys.map(k => {
        const label = k === 'BACK' ? 'Cancella lettera' : k === 'ENTER' ? 'Invia parola' : `Lettera ${k}`;
        const cls = `key${k.length > 1 ? ' wide' : ''}${seen[k] ? ' ' + seen[k] : ''}`;
        return `<button type="button" class="${cls}" data-key="${k}" aria-label="${label}">${k === 'BACK' ? BACKSPACE : k === 'ENTER' ? 'INVIO' : k}</button>`;
      }).join('')}</div>`;
    }).join('');
  }
  function keyPressed(k) {
    if (revealing || !$('modalScrim').hidden || state.game.status !== 'playing') return;
    const g = state.game;
    if (k === 'BACKSPACE' || k === 'BACK') {
      if (g.current) { g.current = g.current.slice(0,-1); save(); renderBoard(); }
      return;
    }
    if (k === 'ENTER') { submit(); return; }
    if (!/^[A-Z]$/.test(k) || g.current.length >= 5) return;
    g.current += k;
    save();
    renderBoard();
    const tile = $('board').children[g.guesses.length]?.children[g.current.length - 1];
    if (tile && !isReduced) tile.classList.add('pop');
  }
  function submit() {
    const g = state.game, word = g.current;
    if (word.length !== 5) { invalid('Servono 5 lettere.'); return; }
    if (!allowed.has(word)) { invalid('Parola non presente nel dizionario.'); return; }
    if (g.hard) {
      const issue = ENGINE.checkHardMode(word, g.guesses);
      if (issue) { invalid(issue); return; }
    }
    const marks = ENGINE.scoreGuess(word, g.answer);
    const r = g.guesses.length;
    g.guesses.push({word,marks});
    g.current = '';
    if (word === g.answer) completeRound(true);
    else if (g.guesses.length === 6) completeRound(false);
    save();
    revealing = true;
    renderBoard();
    // Nascondi momentaneamente i risultati per svelarli uno dopo l'altro.
    const targetRow = $('board').children[r];
    const tiles = Array.from(targetRow.children);
    tiles.forEach((tile,i) => {
      tile.classList.remove(marks[i]);
      if (!isReduced) {
        defer(() => {
          tile.classList.add(marks[i], 'flip');
          tile.style.animationDelay = '0ms';
        }, i * 190);
      } else tile.classList.add(marks[i]);
    });
    const duration = isReduced ? 0 : 5 * 190 + 210;
    defer(() => {
      revealing = false;
      render();
      if (g.status !== 'playing') {
        if (g.status === 'won' && !isReduced) {
          Array.from($('board').children[r].children).forEach((tile, i) => defer(() => {
            // L'animazione è decorativa: non blocca la prossima partita.
            if (tile.isConnected) tile.classList.add('win-bounce');
          },i * 85));
        }
        defer(showResult, isReduced ? 80 : 450);
      }
    }, duration);
  }
  function invalid(message) {
    toast(message);
    const active = $('board').children[state.game.guesses.length];
    if (!isReduced && active) {
      active.classList.remove('shake');
      void active.offsetWidth;
      active.classList.add('shake');
    }
  }
  function toast(message) {
    clearTimeout(toastTimeout);
    $('toast').textContent = message;
    $('toast').classList.add('shown');
    toastTimeout = defer(() => $('toast').classList.remove('shown'), 2350);
  }
  function stopAuto() {
    if (autoInterval) clearInterval(autoInterval);
    autoInterval = null;
    autoRemaining = 0;
  }
  function scheduleAuto() {
    stopAuto();
    if (!state.settings.auto || state.game.status === 'playing') return;
    autoRemaining = 15;
    refreshAutoLabel();
    autoInterval = window.setInterval(() => {
      if (document.hidden) return; // Non consumare il timer mentre la scheda non è visibile.
      if (modalType && modalType !== 'result') return;
      autoRemaining--;
      refreshAutoLabel();
      if (autoRemaining <= 0) beginNewRound();
    },1000);
  }
  function refreshAutoLabel() {
    const el = $('autoStatus');
    if (el) el.textContent = `Nuova partita automatica tra ${autoRemaining} s · Disattivabile nelle impostazioni`;
  }
  function showResult() {
    if (state.game.status === 'playing') return;
    const win = state.game.status === 'won';
    const g = state.game;
    const header = win ? 'Parola trovata!' : 'Ci riproviamo?';
    const intro = win ? `Complimenti! Hai indovinato in <strong>${g.guesses.length} ${g.guesses.length === 1 ? 'tentativo' : 'tentativi'}</strong>.` : `Hai esaurito i 6 tentativi. La prossima parola potrebbe essere quella giusta.`;
    openModal('result',header,win ? 'MISSIONE COMPIUTA' : 'PARTITA TERMINATA', `
      <span class="result-badge">${win ? '✓ VITTORIA' : '↻ NUOVO TENTATIVO'}</span>
      <p class="result-message">${intro}</p>
      <div class="word-reveal"><span class="reveal-label">LA PAROLA ERA</span><strong>${g.answer}</strong></div>
      <div class="modal-actions"><button class="modal-action secondary" id="shareResult">Condividi</button><button class="modal-action" id="playAgain">Gioca ancora →</button></div>
      ${state.settings.auto ? '<div class="auto-status" id="autoStatus"></div>' : '<p class="auto-status">Nuova partita quando vuoi, senza limiti.</p>'}
    `);
    $('playAgain').addEventListener('click', beginNewRound);
    $('shareResult').addEventListener('click', shareResult);
    scheduleAuto();
  }
  function shareResult() {
    const g = state.game;
    const icons = {correct:'🟩',present:'🟨',absent:'⬛'};
    const text = `CINQUE. #${state.number} ${g.status === 'won' ? g.guesses.length : 'X'}/6\n${g.guesses.map(row => row.marks.map(m=>icons[m]).join('')).join('\n')}\n\nGioca anche tu: ${location.protocol === 'http:' || location.protocol === 'https:' ? location.href.split('#')[0].split('?')[0] : 'CINQUE. – Parole infinite'}`;
    const copied = () => toast('Risultato copiato!');
    // Il share sheet di iOS è preferibile se disponibile.
    if (navigator.share) navigator.share({text}).catch(err => { if (err.name !== 'AbortError') copyFallback(text, copied); });
    else copyFallback(text,copied);
  }
  function copyFallback(text, onSuccess) {
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(onSuccess).catch(() => toast('Condivisione non disponibile.'));
    else toast('Condivisione disponibile dopo la pubblicazione HTTPS.');
  }
  function openModal(type, title, eyebrow, html) {
    lastFocused = document.activeElement;
    modalType = type;
    $('modalTitle').textContent = title;
    $('modalEyebrow').textContent = eyebrow;
    $('modalContent').innerHTML = html;
    $('modalScrim').hidden = false;
    document.body.classList.add('modal-open');
    $('closeModalBtn').focus();
  }
  function closeModal() {
    if ($('modalScrim').hidden) return;
    $('modalScrim').hidden = true;
    $('modalContent').innerHTML = '';
    modalType = '';
    document.body.classList.remove('modal-open');
    if (lastFocused?.isConnected) lastFocused.focus({preventScroll:true});
  }
  function showHelp() {
    openModal('help','Come si gioca','REGOLE / 01', `
      <p>Indovina una <strong>parola italiana di 5 lettere</strong> in massimo <strong>6 tentativi</strong>. Dopo ogni parola, le caselle cambiano colore.</p>
      <div class="ex-row"><span class="ex-tile correct">C</span><span class="ex-tile">A</span><span class="ex-tile">N</span><span class="ex-tile">T</span><span class="ex-tile">O</span></div>
      <p class="example-caption"><strong>Verde:</strong> la C è nella posizione corretta.</p>
      <div class="ex-row"><span class="ex-tile">C</span><span class="ex-tile present">A</span><span class="ex-tile">N</span><span class="ex-tile">T</span><span class="ex-tile">O</span></div>
      <p class="example-caption"><strong>Giallo:</strong> la A è presente ma in un'altra posizione.</p>
      <div class="ex-row"><span class="ex-tile">C</span><span class="ex-tile">A</span><span class="ex-tile absent">N</span><span class="ex-tile">T</span><span class="ex-tile">O</span></div>
      <p class="example-caption"><strong>Grigio:</strong> la N non è nella parola, oppure è già stata conteggiata altrove.</p>
      <div class="separator"></div>
      <p><strong>Partite infinite:</strong> premi «NUOVA» quando vuoi. Dopo una partita conclusa puoi avviare subito la successiva; l'avvio automatico è configurabile.</p>
      <p><strong>Modalità difficile:</strong> usa i suggerimenti scoperti nei tentativi precedenti: conserva le lettere verdi nella loro posizione e riutilizza quelle gialle.</p>
      <button class="modal-action" id="understoodBtn">Ho capito, giochiamo →</button>
    `);
    $('understoodBtn').addEventListener('click',closeModal);
  }
  function showStats() {
    const s = state.stats;
    const percent = s.games ? Math.round(s.wins / s.games * 100) : 0;
    const max = Math.max(...s.distribution,1);
    openModal('stats','Le tue statistiche','PROGRESSI / PERSONALI', `
      <div class="stat-big-row">
        <div class="stat-big"><b>${s.games}</b><span>Partite</span></div>
        <div class="stat-big"><b>${percent}%</b><span>Vittorie</span></div>
        <div class="stat-big"><b>${s.streak}</b><span>Serie attuale</span></div>
        <div class="stat-big"><b>${s.best}</b><span>Serie record</span></div>
      </div>
      <div class="hist-label">DISTRIBUZIONE DEI TENTATIVI VINCENTI</div>
      ${s.distribution.map((n,i) => `<div class="hist-row"><span class="hist-n">${i+1}</span><div class="hist-track"><div class="hist-fill${n === 0 ? ' zero' : ''}" style="width:${n===0 ? '100' : Math.max(12,n/max*100)}%">${n}</div></div></div>`).join('')}
      <p class="modal-footer-text">I progressi sono salvati solo su questo dispositivo e browser. Non vengono inviati a server.</p>
      <button class="modal-action" id="statsBackBtn">Torna al gioco</button>
    `);
    $('statsBackBtn').addEventListener('click',closeModal);
  }
  function showSettings() {
    const s = state.settings;
    openModal('settings','Impostazioni','PERSONALIZZA / 03', `
      <div class="settings-line"><div><strong>Tema scuro</strong><small>Passa dal tema chiaro al tema scuro.</small></div><button type="button" class="switch${s.theme === 'dark' ? ' on' : ''}" role="switch" aria-checked="${s.theme === 'dark'}" aria-label="Tema scuro" id="themeSwitch"></button></div>
      <div class="settings-line"><div><strong>Modalità difficile</strong><small>Obbliga a utilizzare gli indizi già scoperti. Si applica dalla prossima partita.</small></div><button type="button" class="switch${s.hard ? ' on' : ''}" role="switch" aria-checked="${s.hard}" aria-label="Modalità difficile" id="hardSwitch"></button></div>
      <div class="settings-line"><div><strong>Nuova partita automatica</strong><small>Dopo una vittoria o sconfitta, ricomincia dopo 15 secondi. Puoi sempre usare «Gioca ancora».</small></div><button type="button" class="switch${s.auto ? ' on' : ''}" role="switch" aria-checked="${s.auto}" aria-label="Nuova partita automatica" id="autoSwitch"></button></div>
      <div class="separator"></div>
      <p><strong>App su iPhone:</strong> apri il sito con Safari, premi <strong>Condividi</strong> (quadrato con freccia) e seleziona <strong>Aggiungi alla schermata Home</strong>. Funziona anche offline dopo il primo caricamento.</p>
      <button class="modal-action secondary" id="settingsCloseBtn">Salva e chiudi</button>
    `);
    for (const [id,run] of Object.entries({
      themeSwitch: () => { s.theme = s.theme === 'dark' ? 'light' : 'dark'; document.body.dataset.theme = s.theme; document.querySelector('meta[name="theme-color"]').content = s.theme === 'dark' ? '#10101b' : '#f6f5fa'; },
      hardSwitch: () => { s.hard = !s.hard; if (state.game.guesses.length === 0 && state.game.status === 'playing') state.game.hard = s.hard; },
      autoSwitch: () => { s.auto = !s.auto; if (!s.auto) stopAuto(); else if (state.game.status !== 'playing') scheduleAuto(); }
    })) {
      $(id).addEventListener('click', () => {
        run();
        const b = $(id);
        const on = id === 'themeSwitch' ? s.theme === 'dark' : id === 'hardSwitch' ? s.hard : s.auto;
        b.classList.toggle('on',on); b.setAttribute('aria-checked',String(on));
        save(); renderStats();
      });
    }
    $('settingsCloseBtn').addEventListener('click', () => { closeModal(); render(); });
  }
  // Inizializzazione.
  if (!state.game) {
    state.number = 0;
    beginNewRound();
  } else render();
  $('keyboard').addEventListener('click', e => { const key = e.target.closest('[data-key]'); if (key) keyPressed(key.dataset.key); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !$('modalScrim').hidden) { closeModal(); return; }
    if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
    if (!$('modalScrim').hidden) {
      if (e.key === 'Tab') {
        const selectable = [...$('modalScrim').querySelectorAll('button:not(:disabled), a[href]')];
        const current = selectable.indexOf(document.activeElement);
        if (selectable.length && ((e.shiftKey && current === 0) || (!e.shiftKey && current === selectable.length - 1))) {
          e.preventDefault(); (e.shiftKey ? selectable[selectable.length-1] : selectable[0]).focus();
        }
      }
      return;
    }
    if (e.key === 'Backspace' || e.key === 'Enter' || (/^[A-Za-zÀ-ÿ]$/.test(e.key))) {
      e.preventDefault();
      const key = e.key === 'Backspace' ? 'BACK' : e.key === 'Enter' ? 'ENTER' : e.key.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
      keyPressed(key);
    }
  });
  $('newGameBtn').addEventListener('click', confirmNewRound);
  $('helpBtn').addEventListener('click',showHelp);
  $('shortHelpBtn').addEventListener('click',showHelp);
  $('statsBtn').addEventListener('click',showStats);
  $('settingsBtn').addEventListener('click',showSettings);
  $('closeModalBtn').addEventListener('click',closeModal);
  $('modalScrim').addEventListener('click', e => { if (e.target === $('modalScrim')) closeModal(); });
  if (state.game.status !== 'playing') scheduleAuto();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
  }
})();
